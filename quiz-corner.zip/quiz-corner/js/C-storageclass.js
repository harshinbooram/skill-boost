const quiz=[
{
	q:'which of the following is not a storage class specifier?',
	options:['auto','register','extern','volatile'],
	answer:0
},
{
	q:'what is the inital value of register storage class specifier',
	options:['0','Null','Garbage','Infinite'],
	answer:2
},
{
	q:'What is the scope of extern class specifier?',
	options:['Within block','Within Program','Global Multiple files','None of the above'],
	answer:2
},
{
	q:'What is the scope of static class specifier?',
	options:['Within block','Within Program','Global Multiple files','None of the above'],
	answer:0
},
{
	q:'what is the inital value of extern storage class specifier?',
	options:['0','Null','Garbage','Infinite'],
	answer:0
},
{
	q:'What will be output for the folowing code?',
	options:['2 1','0 0','3 2','Compilation error'],
	answer:2
},
{
	q:'What will be output for the folowing code?',
	options:['5','6','4','Compilation error'],
	answer:2
},
{
	q:'An identifier storage class determines',
	options:['The time during which the identifier exists in memory','Which function is to use','Where to store the program','None of them'],
	answer:0
},
{
	q:'how many storage classes in c?',
	options:['2','3','4','5'],
	answer:2
},
{
	q:'Which is not a storage class?',
	options:['Auto','Struct','Typedef','Static'],
	answer:1
},
{
	q:'Which of s, t and u are available to a function present in another file?',
	options:['Only s','S & u','S, t, u','None'],
	answer:0
},
{
	q:'In case of a conflict between the names of a local and global variable what happens?',
	options:['The global variable is given a priority','The local variable is given a priority','Which one will get a priority depends upon which one is defined first','The compiler reports an error'],
	answer:1
},
{
	q:'Where will the space be allocated for an automatic storage class variable?',
	options:['In CPU register','In memory as well as in CPU register','In memory','On disk'],
	answer:2
},
{
	q:'For which of the following situation should the register storage class be used?',
	options:['For local variable in a function','For loop counter','For collecting values returned from a function','For variables used in a recursive function'],
	answer:1
},
{
	q:'Which of the following statement is correct? (i) A function can also be declared as static. (ii) The default value of an external storage class variable is zero',
	options:['Only I is correct','Only II is correct','Both I & II are correct','Both I & II are incorrect'],
	answer:2
}
]