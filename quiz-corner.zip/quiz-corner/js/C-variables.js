const quiz=[
{
	q:'How many keywords are there in c ?',
	options:['31','32','64','63'],
	answer:1
},
{
	q:'Which of the following is true for variable names in C?',
	options:['Variable names cannot start with a digit','Variable can be of any length','They can contain alphanumeric characters as well as special characters','Reserved Word can be used as variable name'],
	answer:0
},
{
	q:'Which of the following cannot be a variable name in C?',
	options:['TRUE','friend','export','volatile'],
	answer:3
},
{
	q:'What is size of int in C ?',
	options:['2 bytes','4 bytes','8 bytes','Depends on the system/compiler'],
	answer:3
},
{
	q:'Range of double is -1.7e-38 to 1.7e+38 (in 16 bit platform - Turbo C under DOS)',
	options:['TRUE','FALSE','May Be','Cannot Say'],
	answer:1
},
{
	q:'Which is false?',
	options:['Constant variables need not be defined as they are declared and can be defined later','Global constant variables are initialized to zero','const keyword is used to define constant values','You cannot reassign a value to a constant variable'],
	answer:0
},
{
	q:'If you pass an array as an argument to a function, what actually gets passed?',
	options:['Address of last element of Array','Value of first element','Base address of array','Value of elements in array'],
	answer:2
},
{
	q:'When double is converted to float, the value is?',
	options:['Rounded','Truncated','Depends on the standard','Depends on the compiler'],
	answer:3
},
{
	q:'Which of the following is not a logical operator?',
	options:['!','&&','||','|'],
	answer:3
},
{
	q:'Which of the following can have different meaning in different contexts?',
	options:['&','*','Both A and B','None of the above'],
	answer:0
},
{
	q:'Which of the following is not a valid declaration in C?',
	options:['short int x;','signed short x;','short x;','unsigned short x;'],
	answer:3
},
{
	q:'The minimum number of temporary variable needed to swap the content two variables is?',
	options:['2','3','0','1'],
	answer:2
},
{
	q:'What is short int in C programming?',
	options:['The basic data type of C','Qualifier','Short is the qualifier and int is the basic datatype','All of the mentioned'],
	answer:2
},
{
	q:'Relational operators cannot be used on:',
	options:['String','float','long','structure'],
	answer:3
},
{
	q:'By default a real number is treated as a',
	options:['float','double','long double','integer'],
	answer:1
}
]