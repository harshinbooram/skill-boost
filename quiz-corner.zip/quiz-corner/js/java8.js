const quiz=[
{
	q:'Which of the following functional interface represents a function that accepts a double-valued argument and produces a long-valued result?',
	options:['DoubleToLongFunction','DoubleUnaryOperator','Function','IntBinaryOperator'],
	answer:0
},
{
	q:'Nashorn the new JavaScript engine is an implementation of',
	options:['javax.engine.Engine','javax.script.Engine','javax.javaScript.Engine','javax.script.ScriptEngine'],
	answer:3
},
{
	q:'What does SAM stand for in context of Functional Interface?',
	options:['Single Ambivalue Method','Single Abstract Method','Simple Active Markup','Simple Abstract Markup'],
	answer:1
},
{
	q:'A pipeline is a sequence of what operations in java 8',
	options:['stream','Functional Programming','Lambda Expression', 'Exceprion Handling'],
	answer:0
},
{
	q:'In Java 8 Interfaces, methods can be:',
	options:['default','static','abstract','both A and B','All the mentioned'],
	answer:4
},
{
	q:'Which of the following gets introduced with Java 8?',
	options:['Lambda expression','Compact profiles','Stream API','Only first two'],
	answer:0
},
{
	q:'How many methods are there in a functional interface in Java 8?',
	options:['0','1','10','any number of methods'],
	answer:1
},
{
	q:'PermGen space has been replaced with which of these in Java 8',
	options:['PermSpace','PermSpaceGen','Metaspace','MetaGenSpace'],
	answer:2
},
{
	q:'Example of functional interfaces',
	options:['java.util.concurrent.Callable','java.lang.Runnable','All','None'],
	answer:2
},
{
	q:'Which is aggregate operation in Java 8',
	options:['filter','map','forEach','All'],
	answer:0
},
{
	q:'If a variable is declared final, it must include ¦¦¦¦¦¦¦. value.',
	options:['integer','no','initial','float'],
	answer:2
},
{
	q:'What is the return type of lambda expression?',
	options:['String','void','Object','Function'],
	answer:3
},
{
	q:'Which statement is true regarding an object?',
	options:['An object is what classes instantiated are from','An object is an instance of a class','An object is a variable','An object is a reference to an attribute'],
	answer:1
},
{
	q:'A functional interface acts as target types for which of the following?',
	options:['Lambda expression','Method reference','Constructor reference','All of the above'],
	answer:3
},
{
	q:'Which of these does Stream map() operates on',
	options:['Class','Interface','Predicate','Function'],
	answer:3
}
]