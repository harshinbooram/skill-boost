const quiz=[
{
	q:'Which of these type parameters is used for a generic class to return and accept a number?',
	options:['K','N','T','V'],
	answer:1
},
{
	q:'Which of the following allows us to call generic methods as a normal method?',
	options:['Type Interface','Interface','Inner class','All of the mentioned'],
	answer:0
},
{
	q:'Which of the following is Faster, StringBuilder or StringBuffer?',
	options:['StringBuilder','StringBuffer','Both of the above','None of the above'],
	answer:0
},
{
	q:'Why are generics used?',
	options:['Generics make code more fastB. Generics make code more optimised and readable','Generics add stability to your code by making more of your bugs detectable at compile time','Generics add stability to your code by making more of your bugs detectable at a runtime'],
	answer:2
},
{
	q:'Which of the following reference types cannot be generic?',
	options:['Anonymous inner class','Interface','Inner class','All of the mentioned'],
	answer:0
},
{
	q:'What is the default value of byte variable?',
	options:['0','0.5','null','undefined'],
	answer:0
},
{
	q:'Which of these types cannot be used to initiate a generic type?',
	options:['Integer class','Float Class','Primitive Types','Collections'],
	answer:2
},
{
	q:'Which of these is a correct way of defining of a generic method?',
	options:['name(T1, T2, "¦, Tn) { /* "¦ */ }','public name { /* "¦ */ }','class name[T1, T2, "¦, Tn] { /* "¦ */ }','name{T1, T2, "¦, Tn} { /* "¦ */ }'],
	answer:2
},
{
	q:'Which of these instances cannot be created?',
	options:['Integer Instance','Generic Class Instance','Generic Type Instance','Collection Instances'],
	answer:2
},
{
	q:'Which of these Exception handlers cannot be type parameterized?',
	options:['catch','throw','throws','All of the mentioned'],
	answer:3
},
{
	q:'Which of the following cannot be Type parameterized?',
	options:['Overloaded Methods','Generic methods','Class methods','Overriding methods'],
	answer:0
},
{
	q:'Which of these type of parameters is used for a generic class to return and accept any type of object?',
    options:['K','N','T','B'],
	answer:2
},
{
	q:'Are generics in C# are same as the generics in java and templates in C++',
	options:['yes','no','may be'],
	answer:1
},
{
	q:'What does the following code block defines?  class Gen<T> {  T ob;  }',
	options:['Generics class decleration','a simple class decleration','All of the mentioned'],
	answer:0
},
{
	q:'Select the type arguement of open constructed type?',
	options:['Gen','Gen','Gen<>','None of the mentioned'],
	answer:2
}
]