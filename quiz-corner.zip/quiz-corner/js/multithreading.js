const quiz=[
{
	q:'In java multi-threading, a thread can be created by',
	options:['Extending Thread class','Implementing Runnable interface','Using both','None'],
	answer:2
},
{
	q:'Which method is called internally by Thread start() method?',
	options:['execute()','run()','launch()','main()'],
	answer:1
},
{
	q:'What is maximum thread priority in Java',
	options:['10','5','8','1'],
	answer:0
},
{
	q:'What is Minimum thread priority in Java',
	options:['10','5','1','8'],
	answer:2
},
{
	q:'What is Default thread priority in Java',
	options:['10','5','1','0'],
	answer:1
},
{
	q:'Which method must be implemented by a Java thread?',
	options:['run()','execute()','start()','None'],
	answer:0
},
{
	q:'Execution of a java thread begins on which method call?',
	options:['Start ()','Run ()','Execute ()','Launch ()'],
	answer:0
},
{
	q:'How many ways a thread can be created in Java multithreading?',
	options:['1','2','3','5','many ways'],
	answer:1
},
{
	q:'Which statements is/are correct',
	options:['On calling Thread start () method a new thread get created','Thread run () method can also be called directly to create thread','All correct','None of the mentioned'],
	answer:0
},
{
	q:'Which method is used to make main thread to wait for all child threads',
	options:['Join ()','Sleep ()','Wait ()','Stop ()'],
	answer:0
},
{
	q:'If a priority of a java thread is 3 then the default priority of its child thread will be',
	options:['0','1','5','3'],
	answer:3
},
{
	q:'Which method is used to check if a thread is running?',
	options:['isAlive()','run ()','alive ()','keepAlive()'],
	answer:0
},
{
	q:'Which method we implement from Runnable interface?',
	options:['Run ()','Start ()','Execute ()','call ()'],
	answer:0
},
{
	q:'Daemon thread runs in',
	options:['Background','Foreground','Both','none'],
	answer:0
},
{
	q:'To create a daemon thread',
	options:['First thread setDaemon() is called then start()','First thread start() is called then setDaemon()','Call thread start() and setDaemon() in any order','All correct'],
	answer:0
}
]